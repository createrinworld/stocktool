import Component from "../stock-analyzer"

export default function Page() {
  return <Component />
}
