const { contextBridge, ipcRenderer } = require("electron")

// 暴露安全的API给渲染进程
contextBridge.exposeInMainWorld("electronAPI", {
  // 导出数据
  exportData: (data, format) => {
    ipcRenderer.invoke("export-data", data, format)
  },

  // 打开通达信
  openTongdaxin: (stockCode) => {
    ipcRenderer.invoke("open-tongdaxin", stockCode)
  },

  // 获取应用版本
  getVersion: () => {
    return ipcRenderer.invoke("get-version")
  },
})
