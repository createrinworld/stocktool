# 股票人气分析器

## 快速开始

### 开发环境运行
\`\`\`bash
npm install
npm run dev
\`\`\`

### 打包成EXE文件
\`\`\`bash
# Windows用户可直接双击
build.bat

# 或手动执行
npm install
npm run dist
\`\`\`

### 打包后文件位置
- `dist/股票人气分析器 Setup 1.0.0.exe` - 安装程序
- `dist/股票人气分析器 1.0.0.exe` - 便携版

## 系统要求
- Windows 10/11 (64位)
- 4GB RAM
- 100MB 硬盘空间

## 使用说明
1. 双击EXE文件启动程序
2. 等待数据加载完成
3. 使用筛选功能查找目标股票
4. 点击股票代码跳转到通达信
