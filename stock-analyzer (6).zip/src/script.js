const { ipcRenderer } = require("electron")

// 全局变量
let stockData = []
let filteredData = []

// DOM元素
const refreshBtn = document.getElementById("refreshBtn")
const exportCsvBtn = document.getElementById("exportCsvBtn")
const exportJsonBtn = document.getElementById("exportJsonBtn")
const searchInput = document.getElementById("searchInput")
const industryFilter = document.getElementById("industryFilter")
const conceptFilter = document.getElementById("conceptFilter")
const minRankChange = document.getElementById("minRankChange")
const clearFilters = document.getElementById("clearFilters")
const stockTableBody = document.getElementById("stockTableBody")
const loading = document.getElementById("loading")

// 模拟数据生成
function generateMockData() {
  const industries = ["科技", "医药", "金融", "消费", "制造", "能源", "房地产", "通信"]
  const concepts = ["人工智能", "新能源", "芯片", "生物医药", "5G", "新材料", "军工", "环保"]
  const stockNames = [
    "贵州茅台",
    "比亚迪",
    "宁德时代",
    "中国平安",
    "招商银行",
    "五粮液",
    "美的集团",
    "格力电器",
    "腾讯控股",
    "阿里巴巴",
    "中芯国际",
    "药明康德",
    "迈瑞医疗",
    "恒瑞医药",
    "立讯精密",
    "海康威视",
  ]

  return Array.from({ length: 50 }, (_, i) => {
    const previousRank = Math.floor(Math.random() * 100) + 1
    const rankChange = Math.floor(Math.random() * 20) + 1
    const currentRank = Math.max(1, previousRank - rankChange)

    return {
      code: (Math.floor(Math.random() * 900000) + 100000).toString(),
      name: stockNames[Math.floor(Math.random() * stockNames.length)] + (i > 15 ? i : ""),
      currentRank,
      previousRank,
      rankChange,
      industry: industries[Math.floor(Math.random() * industries.length)],
      concept: [
        concepts[Math.floor(Math.random() * concepts.length)],
        concepts[Math.floor(Math.random() * concepts.length)],
      ],
      price: (Math.random() * 200 + 10).toFixed(2),
      changePercent: (Math.random() * 20 - 10).toFixed(2),
      netAmount: Math.floor(Math.random() * 200000000) - 100000000,
      popularity: Math.floor(Math.random() * 1000) + 100,
    }
  })
    .filter((stock) => stock.rankChange > 0 && stock.currentRank <= 100)
    .sort((a, b) => a.currentRank - b.currentRank)
}

// 显示加载状态
function showLoading() {
  loading.style.display = "flex"
}

// 隐藏加载状态
function hideLoading() {
  loading.style.display = "none"
}

// 格式化金额
function formatAmount(amount) {
  const absAmount = Math.abs(amount)
  if (absAmount >= 100000000) {
    return `${(amount / 100000000).toFixed(2)}亿`
  } else if (absAmount >= 10000) {
    return `${(amount / 10000).toFixed(2)}万`
  }
  return amount.toString()
}

// 更新统计信息
function updateStats() {
  document.getElementById("totalStocks").textContent = filteredData.length

  const avgChange =
    filteredData.length > 0
      ? Math.round(filteredData.reduce((sum, stock) => sum + stock.rankChange, 0) / filteredData.length)
      : 0
  document.getElementById("avgChange").textContent = avgChange

  const industries = new Set(stockData.map((stock) => stock.industry))
  document.getElementById("industryCount").textContent = industries.size

  const now = new Date()
  document.getElementById("lastUpdate").textContent = now.toLocaleTimeString()
  document.getElementById("lastDate").textContent = now.toLocaleDateString()
}

// 更新筛选器选项
function updateFilterOptions() {
  // 更新行业筛选器
  const industries = [...new Set(stockData.map((stock) => stock.industry))]
  industryFilter.innerHTML = '<option value="">全部行业</option>'
  industries.forEach((industry) => {
    const option = document.createElement("option")
    option.value = industry
    option.textContent = industry
    industryFilter.appendChild(option)
  })

  // 更新概念筛选器
  const concepts = [...new Set(stockData.flatMap((stock) => stock.concept))]
  conceptFilter.innerHTML = '<option value="">全部概念</option>'
  concepts.forEach((concept) => {
    const option = document.createElement("option")
    option.value = concept
    option.textContent = concept
    conceptFilter.appendChild(option)
  })
}

// 渲染表格
function renderTable() {
  stockTableBody.innerHTML = ""

  filteredData.forEach((stock) => {
    const row = document.createElement("tr")

    row.innerHTML = `
            <td><span class="stock-code" onclick="openTongdaxin('${stock.code}')">${stock.code}</span></td>
            <td>${stock.name}</td>
            <td>#${stock.currentRank}</td>
            <td><span class="rank-change">${stock.rankChange}</span></td>
            <td><span class="badge">${stock.industry}</span></td>
            <td>
                <div class="concept-tags">
                    ${stock.concept.map((c) => `<span class="badge">${c}</span>`).join("")}
                </div>
            </td>
            <td>¥${stock.price}</td>
            <td class="${Number.parseFloat(stock.changePercent) >= 0 ? "price-up" : "price-down"}">
                ${Number.parseFloat(stock.changePercent) >= 0 ? "+" : ""}${stock.changePercent}%
            </td>
            <td class="${stock.netAmount >= 0 ? "net-inflow-positive" : "net-inflow-negative"}">
                ${stock.netAmount >= 0 ? "+" : ""}${formatAmount(stock.netAmount)}
            </td>
            <td>
                <button class="btn btn-primary" onclick="openTongdaxin('${stock.code}')">通达信</button>
            </td>
        `

    stockTableBody.appendChild(row)
  })
}

// 筛选数据
function filterData() {
  filteredData = stockData.filter((stock) => {
    // 搜索筛选
    const searchTerm = searchInput.value.toLowerCase()
    if (searchTerm && !stock.name.toLowerCase().includes(searchTerm) && !stock.code.includes(searchTerm)) {
      return false
    }

    // 行业筛选
    if (industryFilter.value && stock.industry !== industryFilter.value) {
      return false
    }

    // 概念筛选
    if (conceptFilter.value && !stock.concept.includes(conceptFilter.value)) {
      return false
    }

    // 排名变化筛选
    const minChange = Number.parseInt(minRankChange.value)
    if (minChange && stock.rankChange < minChange) {
      return false
    }

    return true
  })

  renderTable()
  updateStats()
}

// 获取数据
async function fetchData() {
  showLoading()

  try {
    // 模拟API延迟
    await new Promise((resolve) => setTimeout(resolve, 1000))

    stockData = generateMockData()
    filteredData = [...stockData]

    updateFilterOptions()
    renderTable()
    updateStats()

    // 显示成功消息
    showMessage("数据更新成功", `获取到 ${stockData.length} 只排名上升的股票`)
  } catch (error) {
    showMessage("数据获取失败", "请检查网络连接后重试", "error")
  } finally {
    hideLoading()
  }
}

// 显示消息
function showMessage(title, message, type = "success") {
  // 简单的消息提示实现
  const messageDiv = document.createElement("div")
  messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === "error" ? "#f44336" : "#4CAF50"};
        color: white;
        padding: 15px 20px;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        z-index: 1001;
        max-width: 300px;
    `
  messageDiv.innerHTML = `<strong>${title}</strong><br>${message}`

  document.body.appendChild(messageDiv)

  setTimeout(() => {
    document.body.removeChild(messageDiv)
  }, 3000)
}

// 打开通达信
function openTongdaxin(stockCode) {
  ipcRenderer.invoke("open-tongdaxin", stockCode)
  showMessage("正在打开通达信", `股票代码: ${stockCode}`)
}

// 导出数据
async function exportData(format) {
  const result = await ipcRenderer.invoke("export-data", filteredData, format)
  if (result.success) {
    showMessage("导出成功", `文件已保存到: ${result.path}`)
  } else {
    showMessage("导出取消", "用户取消了导出操作", "error")
  }
}

// 事件监听器
refreshBtn.addEventListener("click", fetchData)
exportCsvBtn.addEventListener("click", () => exportData("csv"))
exportJsonBtn.addEventListener("click", () => exportData("json"))

searchInput.addEventListener("input", filterData)
industryFilter.addEventListener("change", filterData)
conceptFilter.addEventListener("change", filterData)
minRankChange.addEventListener("input", filterData)

clearFilters.addEventListener("click", () => {
  searchInput.value = ""
  industryFilter.value = ""
  conceptFilter.value = ""
  minRankChange.value = ""
  filterData()
})

// 初始化
document.addEventListener("DOMContentLoaded", () => {
  fetchData()
})

// 定时刷新（每5分钟）
setInterval(fetchData, 5 * 60 * 1000)
