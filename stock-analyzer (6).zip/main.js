const { app, BrowserWindow, Menu, shell, dialog, ipcMain } = require("electron")
const path = require("path")
const fs = require("fs")

let mainWindow

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    icon: path.join(__dirname, "icon.png"),
    title: "股票人气分析器 v1.0",
    show: false,
  })

  mainWindow.loadFile("index.html")

  mainWindow.once("ready-to-show", () => {
    mainWindow.show()
  })

  mainWindow.on("closed", () => {
    mainWindow = null
  })

  createMenu()
}

function createMenu() {
  const template = [
    {
      label: "文件",
      submenu: [
        {
          label: "刷新数据",
          accelerator: "F5",
          click: () => mainWindow.webContents.reload(),
        },
        { type: "separator" },
        {
          label: "退出",
          accelerator: "Ctrl+Q",
          click: () => app.quit(),
        },
      ],
    },
    {
      label: "帮助",
      submenu: [
        {
          label: "关于",
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: "info",
              title: "关于股票人气分析器",
              message: "股票人气分析器 v1.0.0",
              detail: "实时监控东方财富人气排名，智能分析股票投资机会。\n\n© 2024 股票分析工具",
            })
          },
        },
      ],
    },
  ]

  const menu = Menu.buildFromTemplate(template)
  Menu.setApplicationMenu(menu)
}

// IPC处理
ipcMain.handle("open-tongdaxin", async (event, stockCode) => {
  const tdxUrl = `tdx://stock/${stockCode}`
  shell.openExternal(tdxUrl)
  return { success: true }
})

ipcMain.handle("export-data", async (event, data, format) => {
  try {
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: `股票分析_${new Date().toISOString().split("T")[0]}.${format}`,
      filters: [
        { name: "CSV文件", extensions: ["csv"] },
        { name: "JSON文件", extensions: ["json"] },
      ],
    })

    if (!result.canceled) {
      let content = ""
      if (format === "csv") {
        const headers = ["股票代码", "股票名称", "当前排名", "排名变化", "行业", "概念", "股价", "涨跌幅", "净流入"]
        const rows = data.map((item) => [
          item.code,
          item.name,
          item.currentRank,
          item.rankChange,
          item.industry,
          item.concept.join(";"),
          item.price,
          item.changePercent,
          item.netAmount,
        ])
        content = [headers.join(","), ...rows.map((row) => row.join(","))].join("\n")
      } else {
        content = JSON.stringify(data, null, 2)
      }

      fs.writeFileSync(result.filePath, content, "utf8")
      return { success: true, path: result.filePath }
    }

    return { success: false }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

app.whenReady().then(createWindow)

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit()
  }
})

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})

// 防止多实例
const gotTheLock = app.requestSingleInstanceLock()
if (!gotTheLock) {
  app.quit()
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })
}
