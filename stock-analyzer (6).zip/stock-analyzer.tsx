"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Download, RefreshCw, TrendingUp, ExternalLink, Filter, Search } from "lucide-react"
import { toast } from "@/hooks/use-toast"

// 模拟股票数据类型
interface StockData {
  code: string
  name: string
  currentRank: number
  previousRank: number
  rankChange: number
  industry: string
  concept: string[]
  buyAmount: number
  sellAmount: number
  netAmount: number
  price: number
  changePercent: number
  volume: number
  popularity: number
}

// 模拟数据生成
const generateMockData = (): StockData[] => {
  const industries = ["科技", "医药", "金融", "消费", "制造", "能源", "房地产", "通信"]
  const concepts = ["人工智能", "新能源", "芯片", "生物医药", "5G", "新材料", "军工", "环保"]
  const stockNames = [
    "贵州茅台",
    "比亚迪",
    "宁德时代",
    "中国平安",
    "招商银行",
    "五粮液",
    "美的集团",
    "格力电器",
    "腾讯控股",
    "阿里巴巴",
    "中芯国际",
    "药明康德",
    "迈瑞医疗",
    "恒瑞医药",
    "立讯精密",
    "海康威视",
  ]

  return Array.from({ length: 50 }, (_, i) => {
    const previousRank = Math.floor(Math.random() * 100) + 1
    const rankChange = Math.floor(Math.random() * 20) - 10
    const currentRank = Math.max(1, previousRank - rankChange)

    return {
      code: `${(Math.floor(Math.random() * 900000) + 100000).toString()}`,
      name: stockNames[Math.floor(Math.random() * stockNames.length)] + (i > 15 ? `${i}` : ""),
      currentRank,
      previousRank,
      rankChange,
      industry: industries[Math.floor(Math.random() * industries.length)],
      concept: [
        concepts[Math.floor(Math.random() * concepts.length)],
        concepts[Math.floor(Math.random() * concepts.length)],
      ],
      buyAmount: Math.floor(Math.random() * 1000000000),
      sellAmount: Math.floor(Math.random() * 1000000000),
      netAmount: Math.floor(Math.random() * 200000000) - 100000000,
      price: Math.floor(Math.random() * 200) + 10,
      changePercent: Math.random() * 20 - 10,
      volume: Math.floor(Math.random() * 10000000),
      popularity: Math.floor(Math.random() * 1000) + 100,
    }
  })
    .filter((stock) => stock.rankChange > 0 && stock.currentRank <= 100)
    .sort((a, b) => a.currentRank - b.currentRank)
}

export default function Component() {
  const [stockData, setStockData] = useState<StockData[]>([])
  const [filteredData, setFilteredData] = useState<StockData[]>([])
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedIndustry, setSelectedIndustry] = useState("all")
  const [selectedConcept, setSelectedConcept] = useState("all")
  const [minRankChange, setMinRankChange] = useState("")
  const [lastUpdateTime, setLastUpdateTime] = useState<Date>(new Date())

  // 获取数据
  const fetchData = async () => {
    setLoading(true)
    try {
      // 模拟API调用延迟
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const data = generateMockData()
      setStockData(data)
      setFilteredData(data)
      setLastUpdateTime(new Date())
      toast({
        title: "数据更新成功",
        description: `获取到 ${data.length} 只排名上升的股票`,
      })
    } catch (error) {
      toast({
        title: "数据获取失败",
        description: "请检查网络连接后重试",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // 筛选数据
  useEffect(() => {
    let filtered = stockData

    if (searchTerm) {
      filtered = filtered.filter((stock) => stock.name.includes(searchTerm) || stock.code.includes(searchTerm))
    }

    if (selectedIndustry !== "all") {
      filtered = filtered.filter((stock) => stock.industry === selectedIndustry)
    }

    if (selectedConcept !== "all") {
      filtered = filtered.filter((stock) => stock.concept.includes(selectedConcept))
    }

    if (minRankChange) {
      filtered = filtered.filter((stock) => stock.rankChange >= Number.parseInt(minRankChange))
    }

    setFilteredData(filtered)
  }, [stockData, searchTerm, selectedIndustry, selectedConcept, minRankChange])

  // 导出数据
  const exportData = (format: "csv" | "json") => {
    const dataToExport = filteredData
    let content = ""
    let filename = ""

    if (format === "csv") {
      const headers = [
        "股票代码",
        "股票名称",
        "当前排名",
        "昨日排名",
        "排名变化",
        "行业",
        "概念",
        "买入金额",
        "卖出金额",
        "净流入",
        "股价",
        "涨跌幅",
        "成交量",
        "人气值",
      ]
      const csvContent = [
        headers.join(","),
        ...dataToExport.map((stock) =>
          [
            stock.code,
            stock.name,
            stock.currentRank,
            stock.previousRank,
            stock.rankChange,
            stock.industry,
            stock.concept.join(";"),
            stock.buyAmount,
            stock.sellAmount,
            stock.netAmount,
            stock.price,
            stock.changePercent.toFixed(2),
            stock.volume,
            stock.popularity,
          ].join(","),
        ),
      ].join("\n")
      content = csvContent
      filename = `股票排名分析_${new Date().toISOString().split("T")[0]}.csv`
    } else {
      content = JSON.stringify(dataToExport, null, 2)
      filename = `股票排名分析_${new Date().toISOString().split("T")[0]}.json`
    }

    const blob = new Blob([content], { type: format === "csv" ? "text/csv" : "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    a.click()
    URL.revokeObjectURL(url)

    toast({
      title: "导出成功",
      description: `已导出 ${dataToExport.length} 条数据为 ${format.toUpperCase()} 格式`,
    })
  }

  // 打开通达信
  const openInTongdaxin = (stockCode: string) => {
    // 通达信的URL协议格式
    const tdxUrl = `tdx://stock/${stockCode}`

    try {
      window.open(tdxUrl, "_blank")
      toast({
        title: "正在打开通达信",
        description: `股票代码: ${stockCode}`,
      })
    } catch (error) {
      toast({
        title: "无法打开通达信",
        description: "请确保已安装通达信软件",
        variant: "destructive",
      })
    }
  }

  // 格式化金额
  const formatAmount = (amount: number) => {
    if (amount >= 100000000) {
      return `${(amount / 100000000).toFixed(2)}亿`
    } else if (amount >= 10000) {
      return `${(amount / 10000).toFixed(2)}万`
    }
    return amount.toString()
  }

  // 获取所有行业和概念用于筛选
  const industries = Array.from(new Set(stockData.map((stock) => stock.industry)))
  const concepts = Array.from(new Set(stockData.flatMap((stock) => stock.concept)))

  useEffect(() => {
    fetchData()
    // 设置定时刷新（每5分钟）
    const interval = setInterval(fetchData, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* 头部 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">东方财富人气股票分析</h1>
          <p className="text-muted-foreground mt-2">实时监控人气排名前100股票，筛选排名上升的优质标的</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={fetchData} disabled={loading} variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            刷新数据
          </Button>
          <Button onClick={() => exportData("csv")} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            导出CSV
          </Button>
          <Button onClick={() => exportData("json")} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            导出JSON
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">排名上升股票</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{filteredData.length}</div>
            <p className="text-xs text-muted-foreground">较昨日排名提升</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">平均排名提升</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {filteredData.length > 0
                ? Math.round(filteredData.reduce((sum, stock) => sum + stock.rankChange, 0) / filteredData.length)
                : 0}
            </div>
            <p className="text-xs text-muted-foreground">位次</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">涉及行业</CardTitle>
            <Filter className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{industries.length}</div>
            <p className="text-xs text-muted-foreground">个行业</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">最后更新</CardTitle>
            <RefreshCw className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-bold text-orange-600">{lastUpdateTime.toLocaleTimeString()}</div>
            <p className="text-xs text-muted-foreground">{lastUpdateTime.toLocaleDateString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* 筛选器 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            数据筛选
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">搜索股票</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="股票名称或代码"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>行业筛选</Label>
              <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                <SelectTrigger>
                  <SelectValue placeholder="选择行业" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部行业</SelectItem>
                  {industries.map((industry) => (
                    <SelectItem key={industry} value={industry}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>概念筛选</Label>
              <Select value={selectedConcept} onValueChange={setSelectedConcept}>
                <SelectTrigger>
                  <SelectValue placeholder="选择概念" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部概念</SelectItem>
                  {concepts.map((concept) => (
                    <SelectItem key={concept} value={concept}>
                      {concept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="rankChange">最小排名提升</Label>
              <Input
                id="rankChange"
                type="number"
                placeholder="输入数字"
                value={minRankChange}
                onChange={(e) => setMinRankChange(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>&nbsp;</Label>
              <Button
                onClick={() => {
                  setSearchTerm("")
                  setSelectedIndustry("all")
                  setSelectedConcept("all")
                  setMinRankChange("")
                }}
                variant="outline"
                className="w-full"
              >
                清除筛选
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 数据表格 */}
      <Card>
        <CardHeader>
          <CardTitle>股票列表 ({filteredData.length})</CardTitle>
          <CardDescription>显示排名较昨日上升的股票，点击股票代码可在通达信中查看</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>股票代码</TableHead>
                  <TableHead>股票名称</TableHead>
                  <TableHead>当前排名</TableHead>
                  <TableHead>排名变化</TableHead>
                  <TableHead>行业</TableHead>
                  <TableHead>概念</TableHead>
                  <TableHead>股价</TableHead>
                  <TableHead>涨跌幅</TableHead>
                  <TableHead>净流入</TableHead>
                  <TableHead>人气值</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.map((stock) => (
                  <TableRow key={stock.code}>
                    <TableCell>
                      <Button
                        variant="link"
                        className="p-0 h-auto font-mono text-blue-600"
                        onClick={() => openInTongdaxin(stock.code)}
                      >
                        {stock.code}
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </Button>
                    </TableCell>
                    <TableCell className="font-medium">{stock.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">#{stock.currentRank}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        <span className="text-green-600 font-medium">+{stock.rankChange}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{stock.industry}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {stock.concept.slice(0, 2).map((concept, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {concept}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>¥{stock.price.toFixed(2)}</TableCell>
                    <TableCell>
                      <span className={stock.changePercent >= 0 ? "text-red-600" : "text-green-600"}>
                        {stock.changePercent >= 0 ? "+" : ""}
                        {stock.changePercent.toFixed(2)}%
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={stock.netAmount >= 0 ? "text-red-600" : "text-green-600"}>
                        {stock.netAmount >= 0 ? "+" : ""}
                        {formatAmount(Math.abs(stock.netAmount))}
                      </span>
                    </TableCell>
                    <TableCell>{stock.popularity}</TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" onClick={() => openInTongdaxin(stock.code)}>
                        通达信
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
