const { contextBridge, ipcRenderer } = require("electron")

contextBridge.exposeInMainWorld("electronAPI", {
  openTongdaxin: (stockCode) => ipcRenderer.invoke("open-tongdaxin", stockCode),
  getVersion: () => process.versions.electron,
})
